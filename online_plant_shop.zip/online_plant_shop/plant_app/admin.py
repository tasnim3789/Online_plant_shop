from django.contrib import admin
from plant_app.models import contact

# Register your models here.
admin.site.register(contact)